# Keylogger

**Keylogger** is simple keylogger for Windows, Linux and Mac.
## Installation

The following instructions will install Keylogger with pip Python package manager.

### pip

This installs the latest stable, released version.

```
  $ pip install keylogger
```

## How to run it

By running `keylogger` command, it'll start to log your strokes:
```
$ keylogger

RECORD extension version 1.13
```

The Keylogger is now running! It will log your strokes to the file you specified. Stop it by hitting the grave key (Thats the one under escape on a standard keyboard). 

Keylogger has several options that can be used to change output log file and change its cancel key:

* `--log-file output.og`: File path to use as the log file.  Default is current directory.
* `--cancel-key`: The key that uses as the cancel key, default is '`'.
* `--clean-log`: clean the log file first, default is No.

#### Use cases

Some uses of a keylogger are:

- Business Administration: Monitor what employees are doing.
- School/Institutions: Track keystrokes and log banned words in a file.
- Personal Control and File Backup: Make sure no one is using your computer when you are away.
- Parental Control: Track what your children are doing.
- Self analysis

---

